// This file originally used a non-standard name for this Arduino core
// only, so still expose the old new.h name for compatibility.
#include "new"
